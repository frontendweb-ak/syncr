// src/config/constants/rate-limit.constants.ts

export const RATE_LIMIT = {
  /* -------------------------------------------------------------------------- */
  /* Defaults                                                                    */
  /* -------------------------------------------------------------------------- */

  DEFAULT: { REQUESTS: 60, WINDOW_SECONDS: 60 },
  /* -------------------------------------------------------------------------- */
  /* Authentication                                                              */
  /* -------------------------------------------------------------------------- */

  REGISTER: { REQUESTS: 5, WINDOW_SECONDS: 3600 },
  LOGIN: { REQUESTS: 10, WINDOW_SECONDS: 300 },
  GOOGLE_LOGIN: { REQUESTS: 30, WINDOW_SECONDS: 300 },
  VERIFY_EMAIL: { REQUESTS: 10, WINDOW_SECONDS: 300 },
  REFRESH_TOKEN: { REQUESTS: 60, WINDOW_SECONDS: 300 },
  FORGOT_PASSWORD: { REQUESTS: 5, WINDOW_SECONDS: 3600 },
  RESET_PASSWORD: { REQUESTS: 10, WINDOW_SECONDS: 300 },
  MFA_VERIFY: { REQUESTS: 10, WINDOW_SECONDS: 300 },
  MFA_ENABLE: { REQUESTS: 10, WINDOW_SECONDS: 300 },
  MFA_ENABLE_CONFIRM: { REQUESTS: 10, WINDOW_SECONDS: 300 },
  MFA_DISABLE: { REQUESTS: 5, WINDOW_SECONDS: 300 },
  API_KEY_CREATE: { REQUESTS: 5, WINDOW_SECONDS: 300 },
  ORG_INVITE_CREATE: {
    REQUESTS: 20,
    WINDOW_SECONDS: 3600,
  },

  ORG_INVITE_RESEND: {
    REQUESTS: 5,
    WINDOW_SECONDS: 3600,
  },

  RESEND_VERIFICATION_EMAIL: {
    REQUESTS: 5,
    WINDOW_SECONDS: 3600,
  },
  /* -------------------------------------------------------------------------- */
  /* OAuth / SSO                                                                 */
  /* -------------------------------------------------------------------------- */

  OAUTH: { REQUESTS: 30, WINDOW_SECONDS: 60 },
  SSO: { REQUESTS: 20, WINDOW_SECONDS: 60 },

  /* -------------------------------------------------------------------------- */
  /* API                                                                         */
  /* -------------------------------------------------------------------------- */
  API: { REQUESTS: 300, WINDOW_SECONDS: 60 },
  GRAPHQL: { REQUESTS: 300, WINDOW_SECONDS: 60 },
  REST: { REQUESTS: 300, WINDOW_SECONDS: 60 },

  /* -------------------------------------------------------------------------- */
  /* Uploads                                                                     */
  /* -------------------------------------------------------------------------- */
  UPLOAD: { REQUESTS: 20, WINDOW_SECONDS: 60 },
  /* -------------------------------------------------------------------------- */
  /* Notifications                                                               */
  /* -------------------------------------------------------------------------- */
  EMAIL: { REQUESTS: 20, WINDOW_SECONDS: 3600 },
  SMS: { REQUESTS: 10, WINDOW_SECONDS: 3600 },
  PUSH: { REQUESTS: 60, WINDOW_SECONDS: 60 },

  /* -------------------------------------------------------------------------- */
  /* Messaging                                                                   */
  /* -------------------------------------------------------------------------- */
  MESSAGE: { REQUESTS: 120, WINDOW_SECONDS: 60 },
  /* -------------------------------------------------------------------------- */
  /* Payments                                                                    */
  /* -------------------------------------------------------------------------- */
  PAYMENT: { REQUESTS: 30, WINDOW_SECONDS: 60 },
  /* -------------------------------------------------------------------------- */
  /* Webhooks                                                                    */
  /* -------------------------------------------------------------------------- */
  WEBHOOK: { REQUESTS: 1000, WINDOW_SECONDS: 60 },
  /* -------------------------------------------------------------------------- */
  /* CLI                                                                         */
  /* -------------------------------------------------------------------------- */
  CLI: { REQUESTS: 300, WINDOW_SECONDS: 60 },
  /* -------------------------------------------------------------------------- */
  /* Admin                                                                       */
  /* -------------------------------------------------------------------------- */
  ADMIN: { REQUESTS: 600, WINDOW_SECONDS: 60 },
  /* -------------------------------------------------------------------------- */
  /* Search                                                                      */
  /* -------------------------------------------------------------------------- */
  SEARCH: { REQUESTS: 120, WINDOW_SECONDS: 60 },
  /* -------------------------------------------------------------------------- */
  /* Public APIs                                                                 */
  /* -------------------------------------------------------------------------- */
  PUBLIC: { REQUESTS: 60, WINDOW_SECONDS: 60 },
} as const;

export type RateLimitPolicy = keyof typeof RATE_LIMIT;
